﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Employee.Migrations
{
    /// <inheritdoc />
    public partial class SeedEmployeeDetailsTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "employeeDetails",
                columns: new[] { "EmployeeId", "EmployeeNumber", "FirstName", "HireDate", "LastName" },
                values: new object[,]
                {
                    { 1, 100, "Hima", new DateTime(1999, 1, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), "Bindu" },
                    { 2, 200, "Komala", new DateTime(1997, 4, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "Reddy" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "employeeDetails",
                keyColumn: "EmployeeId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "employeeDetails",
                keyColumn: "EmployeeId",
                keyValue: 2);
        }
    }
}

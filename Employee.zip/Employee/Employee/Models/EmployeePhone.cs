﻿using System.ComponentModel.DataAnnotations;

namespace Employee.Models
{
    public class EmployeePhone
    {
        [Key]
        public int EmployeePhoneId { get; set; }
        public int EmployeeId { get; set; }
        public string PhoneType { get; set; }
        public string PhoneNumber { get; set; }

        // Navigation property for the relationship
        public virtual EmployeeDetails EmployeeDetails { get; set; }

    }
        
}

﻿using Employee.Data;
using Employee.Models;
using Employee.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Text.RegularExpressions;

namespace Employee.Controllers
{
    public class EmployeeDataController : Controller
    {
        public readonly ApplicationDbContext _db;
        //Using ApplicationContext for data
        public EmployeeDataController(ApplicationDbContext db)
        {
            _db = db;
        }
        
        //Create - To create mew employee records by form
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(CreateEmployeeViewModel viewModel)
        {
            if(ModelState.IsValid)
            
            {
                var employee = new EmployeeDetails
            {
                EmployeeNumber= viewModel.EmployeeNumber,
                FirstName= viewModel.FirstName,
                LastName= viewModel.LastName,
                HireDate= viewModel.HireDate
            };
                if(employee.EmployeePhones == null) 
             {
                employee.EmployeePhones = new List<EmployeePhone>()
                    {
                        new EmployeePhone()
                        {
                            PhoneType=viewModel.PhoneType,
                            PhoneNumber= viewModel.PhoneNumber,
                        }
                    
                    };
                };
                if(employee.EmployeeAddresses == null)
                {
                    employee.EmployeeAddresses= new List<EmployeeAddress>()
                    {
                        new EmployeeAddress()
                        {
                            Address1 = viewModel.Address1,
                            Address2 = viewModel.Address2,
                            City= viewModel.City,
                            State = viewModel.State,
                            ZipCode= viewModel.ZipCode
                        }
                    };
                }
                _db.employeeDetails.Add(employee);
                _db.SaveChanges();
                RedirectToAction("Index");
            }
            
            return View(viewModel);
        }
        //To get the details in the Hire Table
        public IActionResult Random()
        {
            var employeeList = _db.employeeDetails.ToList();

            // Group employees by full name
            var groupedEmployees = employeeList.GroupBy(e => $"{e.FirstName} {e.LastName}");

            // List of view models for hire details
            var listHireDetailsObj = new List<HireDetailsViewModel>();

            foreach (var group in groupedEmployees)
            {
                var hireDetailsViewModel = new HireDetailsViewModel();
                hireDetailsViewModel.FullName = group.Key; // Key contains the full name from the grouping

                // Calculate earliest hire date, latest hire date, and average length of employment for the group
                DateTime earliestHireDate = group.Min(e => e.HireDate);
                DateTime latestHireDate = group.Max(e => e.HireDate);
                double averageEmploymentYears = group.Average(e => (DateTime.Now.Year - e.HireDate.Year));

                
                hireDetailsViewModel.EarliestHireDate = earliestHireDate;
                hireDetailsViewModel.LatestHireDate = latestHireDate;
                hireDetailsViewModel.AverageEmploymentYears = averageEmploymentYears;

                listHireDetailsObj.Add(hireDetailsViewModel);
            }

            return View(listHireDetailsObj);
        }
        //To get the Employee Details and phone and ZipCode Filters
        public IActionResult Index(string phoneNumber,string zipCode)
        {
            
            //eager loading all the tables into one
            var employeeList = _db.employeeDetails.Include(d => d.EmployeePhones).Include(p => p.EmployeeAddresses).ToList();
            // Filter by Phone Number if user input is provided
            if (!string.IsNullOrEmpty(phoneNumber))
            {
                employeeList = employeeList
                    .Where(e => e.EmployeePhones.Any(e=> e.PhoneNumber.Contains(phoneNumber)))
                    .ToList();
            }

            // Filter by ZIP Code if user input is provided
            if (!string.IsNullOrEmpty(zipCode))
            {
                employeeList = employeeList
                    .Where(e => e.EmployeeAddresses.Any(e => e.ZipCode.Contains(zipCode)))
                    .ToList();
            }

            //list of viewmodels employee list
            var lstViewModel = new List<EmployeesListViewModel>();
            var distinctEmployees = employeeList
           .GroupBy(e => new { e.FirstName, e.LastName })
           .Select(group => group.First());
            foreach (var employee in distinctEmployees.OrderBy(e => e.FirstName).ThenBy(e => e.LastName))
            {
                var viewModel = new EmployeesListViewModel();
                viewModel.FirstName = employee.FirstName;
                viewModel.LastName = employee.LastName;
                if (employee.EmployeePhones != null) 
                {
                    viewModel.PhoneNumber = employee.EmployeePhones.First().PhoneNumber;
                }
                if (employee.EmployeeAddresses != null)
                {
                    viewModel.Address1 = employee.EmployeeAddresses.First().Address1;
                    viewModel.Address2 = employee.EmployeeAddresses.First().Address2;
                    viewModel.City = employee.EmployeeAddresses.First().City;
                    viewModel.State = employee.EmployeeAddresses.First().State;
                    viewModel.Zipcode = employee.EmployeeAddresses.First().ZipCode;
                }
                lstViewModel.Add(viewModel);
            }
            
            return View(lstViewModel);
        }

       
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Employee.Migrations
{
    /// <inheritdoc />
    public partial class CreateEmployeePhoneAndEmployeeAddress : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeAddress_employeeDetails_EmployeeDetailsEmployeeId",
                table: "EmployeeAddress");

            migrationBuilder.DropForeignKey(
                name: "FK_EmployeePhone_employeeDetails_EmployeeDetailsEmployeeId",
                table: "EmployeePhone");

            migrationBuilder.DropPrimaryKey(
                name: "PK_EmployeePhone",
                table: "EmployeePhone");

            migrationBuilder.DropPrimaryKey(
                name: "PK_EmployeeAddress",
                table: "EmployeeAddress");

            migrationBuilder.RenameTable(
                name: "EmployeePhone",
                newName: "employeePhones");

            migrationBuilder.RenameTable(
                name: "EmployeeAddress",
                newName: "employeeAddresses");

            migrationBuilder.RenameIndex(
                name: "IX_EmployeePhone_EmployeeDetailsEmployeeId",
                table: "employeePhones",
                newName: "IX_employeePhones_EmployeeDetailsEmployeeId");

            migrationBuilder.RenameIndex(
                name: "IX_EmployeeAddress_EmployeeDetailsEmployeeId",
                table: "employeeAddresses",
                newName: "IX_employeeAddresses_EmployeeDetailsEmployeeId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_employeePhones",
                table: "employeePhones",
                column: "EmployeePhoneId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_employeeAddresses",
                table: "employeeAddresses",
                column: "EmployeeAddressId");

            migrationBuilder.AddForeignKey(
                name: "FK_employeeAddresses_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeeAddresses",
                column: "EmployeeDetailsEmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_employeePhones_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeePhones",
                column: "EmployeeDetailsEmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_employeeAddresses_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeeAddresses");

            migrationBuilder.DropForeignKey(
                name: "FK_employeePhones_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeePhones");

            migrationBuilder.DropPrimaryKey(
                name: "PK_employeePhones",
                table: "employeePhones");

            migrationBuilder.DropPrimaryKey(
                name: "PK_employeeAddresses",
                table: "employeeAddresses");

            migrationBuilder.RenameTable(
                name: "employeePhones",
                newName: "EmployeePhone");

            migrationBuilder.RenameTable(
                name: "employeeAddresses",
                newName: "EmployeeAddress");

            migrationBuilder.RenameIndex(
                name: "IX_employeePhones_EmployeeDetailsEmployeeId",
                table: "EmployeePhone",
                newName: "IX_EmployeePhone_EmployeeDetailsEmployeeId");

            migrationBuilder.RenameIndex(
                name: "IX_employeeAddresses_EmployeeDetailsEmployeeId",
                table: "EmployeeAddress",
                newName: "IX_EmployeeAddress_EmployeeDetailsEmployeeId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_EmployeePhone",
                table: "EmployeePhone",
                column: "EmployeePhoneId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_EmployeeAddress",
                table: "EmployeeAddress",
                column: "EmployeeAddressId");

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeAddress_employeeDetails_EmployeeDetailsEmployeeId",
                table: "EmployeeAddress",
                column: "EmployeeDetailsEmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeePhone_employeeDetails_EmployeeDetailsEmployeeId",
                table: "EmployeePhone",
                column: "EmployeeDetailsEmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

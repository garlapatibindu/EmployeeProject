﻿using System.ComponentModel.DataAnnotations;

namespace Employee.Models
{
    public class EmployeeDetails
    {
        [Key]
        public int EmployeeId { get; set; }
        public int EmployeeNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime HireDate { get; set; }

        // Navigation properties for relationships
        public virtual ICollection<EmployeePhone> EmployeePhones { get; set; }
        public virtual ICollection<EmployeeAddress> EmployeeAddresses { get; set; }
    }
}


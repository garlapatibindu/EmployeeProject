﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Employee.Migrations
{
    /// <inheritdoc />
    public partial class SeededNewDataIntoTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "employeeDetails",
                columns: new[] { "EmployeeId", "EmployeeNumber", "FirstName", "HireDate", "LastName" },
                values: new object[] { 3, 300, "Komala", new DateTime(1997, 4, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "Reddy" });

            migrationBuilder.InsertData(
                table: "employeeAddresses",
                columns: new[] { "EmployeeAddressId", "Address1", "Address2", "City", "EmployeeId", "State", "ZipCode" },
                values: new object[] { 3, "Saint Apartments", "Apt 803", "Tampa", 3, "Florida", "33095" });

            migrationBuilder.InsertData(
                table: "employeePhones",
                columns: new[] { "EmployeePhoneId", "EmployeeId", "PhoneNumber", "PhoneType" },
                values: new object[] { 3, 3, "9603854314", "Landline" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "employeeAddresses",
                keyColumn: "EmployeeAddressId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "employeePhones",
                keyColumn: "EmployeePhoneId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "employeeDetails",
                keyColumn: "EmployeeId",
                keyValue: 3);
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Employee.Migrations
{
    /// <inheritdoc />
    public partial class SeedNewData1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "employeeDetails",
                columns: new[] { "EmployeeId", "EmployeeNumber", "FirstName", "HireDate", "LastName" },
                values: new object[] { 4, 400, "ammy", new DateTime(1997, 4, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "jackson" });

            migrationBuilder.InsertData(
                table: "employeeAddresses",
                columns: new[] { "EmployeeAddressId", "Address1", "Address2", "City", "EmployeeId", "State", "ZipCode" },
                values: new object[] { 4, "Saint Apartments1", "Apt 8039", "Tampa", 4, "Florida", "33095" });

            migrationBuilder.InsertData(
                table: "employeePhones",
                columns: new[] { "EmployeePhoneId", "EmployeeId", "PhoneNumber", "PhoneType" },
                values: new object[] { 4, 4, "1234567891", "mobile" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "employeeAddresses",
                keyColumn: "EmployeeAddressId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "employeePhones",
                keyColumn: "EmployeePhoneId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "employeeDetails",
                keyColumn: "EmployeeId",
                keyValue: 4);
        }
    }
}

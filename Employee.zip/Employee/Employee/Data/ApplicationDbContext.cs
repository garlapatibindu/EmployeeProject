﻿using Employee.Models;
using Microsoft.EntityFrameworkCore;

namespace Employee.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        //Creating employee Deatails,EmployeePhone,EmployeeAddress Tables
        public DbSet<EmployeeDetails> employeeDetails { get; set; }
        public DbSet<EmployeePhone> employeePhones { get; set; }
        public DbSet<EmployeeAddress> employeeAddresses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Seeding Data To the Tables
            modelBuilder.Entity<EmployeeDetails>().HasData
                (
                new EmployeeDetails { EmployeeId = 1, EmployeeNumber = 100, FirstName = "Hima", LastName = "Bindu", HireDate = new DateTime(1999, 01, 30) },

                new EmployeeDetails { EmployeeId = 2, EmployeeNumber = 200, FirstName = "Komala", LastName = "Reddy", HireDate = (DateTime)new DateTime(1977, 04, 14) },
                new EmployeeDetails { EmployeeId = 3, EmployeeNumber = 300, FirstName = "Komala", LastName = "Reddy", HireDate = (DateTime)new DateTime(2000, 04, 14) },
                 new EmployeeDetails { EmployeeId = 4, EmployeeNumber = 400, FirstName = "ammy", LastName = "jackson", HireDate = (DateTime)new DateTime(2017, 04, 14) }


                );


            modelBuilder.Entity<EmployeePhone>().HasData
                (
                new EmployeePhone { EmployeePhoneId = 1, EmployeeId = 1, PhoneType = "Mobile", PhoneNumber = "9132950959" },
                new EmployeePhone { EmployeePhoneId = 2, EmployeeId = 2, PhoneType = "Landline", PhoneNumber = "9603854314" },
                new EmployeePhone { EmployeePhoneId = 3, EmployeeId = 3, PhoneType = "Landline", PhoneNumber = "9603854314" },
                new EmployeePhone { EmployeePhoneId=4,EmployeeId=4,PhoneType="mobile",PhoneNumber="1234567891"}

                );
            modelBuilder.Entity<EmployeeAddress>().HasData
                (
                new EmployeeAddress { EmployeeAddressId = 1, EmployeeId = 1, Address1 = "Lakes at LionsGate", Address2 = "Apt 1506", City = "Overland Park", State = "Kansas", ZipCode = "66223" },
                new EmployeeAddress { EmployeeAddressId = 2, EmployeeId = 2, Address1 = "Saint Apartments", Address2 = "Apt 803", City = "Tampa", State = "Florida",ZipCode="33095" },
                new EmployeeAddress { EmployeeAddressId = 3, EmployeeId = 3, Address1 = "Saint Apartments", Address2 = "Apt 803", City = "Tampa", State = "Florida", ZipCode = "33095" },
                new EmployeeAddress { EmployeeAddressId = 4, EmployeeId = 4, Address1 = "Saint Apartments1", Address2 = "Apt 8039", City = "Tampa", State = "Florida", ZipCode = "33095" }

                );
            //Configuring the Relationships with Foreign Keys
            modelBuilder.Entity<EmployeeDetails>()
                .HasMany(e => e.EmployeePhones)
                .WithOne(ep => ep.EmployeeDetails)
                .HasForeignKey(ep => ep.EmployeeId);

            modelBuilder.Entity<EmployeeDetails>()
                .HasMany(e => e.EmployeeAddresses)
                .WithOne(ea => ea.EmployeeDetails)
                .HasForeignKey(ea => ea.EmployeeId);
        }
    }

}


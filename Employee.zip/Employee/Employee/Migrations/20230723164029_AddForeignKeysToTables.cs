﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Employee.Migrations
{
    /// <inheritdoc />
    public partial class AddForeignKeysToTables : Migration
    {
        /// <inheritdoc 
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            
            migrationBuilder.DropForeignKey(
                name: "FK_employeeAddresses_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeeAddresses");

            migrationBuilder.DropForeignKey(
                name: "FK_employeePhones_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeePhones");

            migrationBuilder.DropIndex(
                name: "IX_employeePhones_EmployeeDetailsEmployeeId",
                table: "employeePhones");

            migrationBuilder.DropIndex(
                name: "IX_employeeAddresses_EmployeeDetailsEmployeeId",
                table: "employeeAddresses");

            migrationBuilder.DropColumn(
                name: "EmployeeDetailsEmployeeId",
                table: "employeePhones");

            migrationBuilder.DropColumn(
                name: "EmployeeDetailsEmployeeId",
                table: "employeeAddresses");

            migrationBuilder.CreateIndex(
                name: "IX_employeePhones_EmployeeId",
                table: "employeePhones",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_employeeAddresses_EmployeeId",
                table: "employeeAddresses",
                column: "EmployeeId");

            migrationBuilder.AddForeignKey(
                name: "FK_employeeAddresses_employeeDetails_EmployeeId",
                table: "employeeAddresses",
                column: "EmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_employeePhones_employeeDetails_EmployeeId",
                table: "employeePhones",
                column: "EmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_employeeAddresses_employeeDetails_EmployeeId",
                table: "employeeAddresses");

            migrationBuilder.DropForeignKey(
                name: "FK_employeePhones_employeeDetails_EmployeeId",
                table: "employeePhones");

            migrationBuilder.DropIndex(
                name: "IX_employeePhones_EmployeeId",
                table: "employeePhones");

            migrationBuilder.DropIndex(
                name: "IX_employeeAddresses_EmployeeId",
                table: "employeeAddresses");

            migrationBuilder.AddColumn<int>(
                name: "EmployeeDetailsEmployeeId",
                table: "employeePhones",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "EmployeeDetailsEmployeeId",
                table: "employeeAddresses",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_employeePhones_EmployeeDetailsEmployeeId",
                table: "employeePhones",
                column: "EmployeeDetailsEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_employeeAddresses_EmployeeDetailsEmployeeId",
                table: "employeeAddresses",
                column: "EmployeeDetailsEmployeeId");

            migrationBuilder.AddForeignKey(
                name: "FK_employeeAddresses_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeeAddresses",
                column: "EmployeeDetailsEmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_employeePhones_employeeDetails_EmployeeDetailsEmployeeId",
                table: "employeePhones",
                column: "EmployeeDetailsEmployeeId",
                principalTable: "employeeDetails",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

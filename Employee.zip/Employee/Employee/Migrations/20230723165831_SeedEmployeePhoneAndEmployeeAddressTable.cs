﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Employee.Migrations
{
    /// <inheritdoc />
    public partial class SeedEmployeePhoneAndEmployeeAddressTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "employeeAddresses",
                columns: new[] { "EmployeeAddressId", "Address1", "Address2", "City", "EmployeeId", "State", "ZipCode" },
                values: new object[,]
                {
                    { 1, "Lakes at LionsGate", "Apt 1506", "Overland Park", 1, "Kansas", "66223" },
                    { 2, "Saint Apartments", "Apt 803", "Tampa", 2, "Florida", "33095" }
                });

            migrationBuilder.InsertData(
                table: "employeePhones",
                columns: new[] { "EmployeePhoneId", "EmployeeId", "PhoneNumber", "PhoneType" },
                values: new object[,]
                {
                    { 1, 1, "9132950959", "Mobile" },
                    { 2, 2, "9603854314", "Landline" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "employeeAddresses",
                keyColumn: "EmployeeAddressId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "employeeAddresses",
                keyColumn: "EmployeeAddressId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "employeePhones",
                keyColumn: "EmployeePhoneId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "employeePhones",
                keyColumn: "EmployeePhoneId",
                keyValue: 2);
        }
    }
}

﻿namespace Employee.ViewModels
{
    public class HireDetailsViewModel
    {
       
        public string FullName { get;set; }
        public DateTime EarliestHireDate { get; set; }
        public DateTime LatestHireDate { get; set; }
        public double AverageEmploymentYears { get;set; }
    }
}
